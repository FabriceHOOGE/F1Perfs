package fr.ldnr.fhe.zoomanager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;

/**
 * Created by fabri on 11/04/2017.
 */

public class MenagerieActivity extends Activity{

    private long start , end;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new MenagerieView(this));
        this.start = System.currentTimeMillis();
    }

    @Override
    public void onBackPressed() {
        this.end = System.currentTimeMillis();
        Intent intent = new Intent();
        intent.putExtra("time",end-start);
        setResult(0,intent);
        Log.i("MenagerieActivity","onBackPressed(): milisecond: " + (end-start));

        //super.onBackPressed(); toujours a la fin cela ferme l'activité actuelle et rend inaccessible ses informations
        super.onBackPressed();
    }

    private class MenagerieView extends View{

        public MenagerieView(Context context)
        {
            super(context);
        }

        protected void onDraw(Canvas canvas)
        {
            super.onDraw(canvas);
            if(getIntent().getBooleanExtra("right",false))
            {

                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.menagerie);
                canvas.drawBitmap(bitmap,0,0,null);
                Log.i("MapMenagerie","onDraw(): false");
            }
            else
            {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.voliere);
                canvas.drawBitmap(bitmap,0,0,null);
                Log.i("MapMenagerie","onDraw(): true");
            }
        }
    }
}
