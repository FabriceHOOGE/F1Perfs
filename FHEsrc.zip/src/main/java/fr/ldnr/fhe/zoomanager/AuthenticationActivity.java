package fr.ldnr.fhe.zoomanager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

/**
 * Created by fabri on 12/04/2017.
 */

public class AuthenticationActivity extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("AuthenticationActivity","onCreate(): ended");
        setContentView(new AuthenticationView(this));
    }

    private class AuthenticationView extends View{
        public AuthenticationView(Context context)
        {
            super(context);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX();
            float y = event.getY();
            Log.i("AuthenticationView","onTouchEvent() : started");
            if(event.getActionMasked() == MotionEvent.ACTION_DOWN)
            {
                Log.i("AuthenticationView","onTouchEvent() : x: " + x + " || y: " + y);

                if((x > (getWidth()/2-60) && x < (getWidth()/2+60))&&(y > (getHeight()/2-150) && y < (getHeight()/2+60)))
                {
                    Log.i("AuthenticationView","onTouchEvent() : j'ai appuyé sur 1");
                    //Création d'un objet d'intention qui effectuera le changement d'activité
                    Intent intent = new Intent(AuthenticationActivity.this, MapActivity.class);
                    //Démarrage de l'activité
                    startActivity(intent);
                }
            }



            //copié de la méthode mais sans avoir compris pourquoi mettre a true.
            return true;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            Log.i("AuthenticationView","onDraw(): started");
            super.onDraw(canvas);

            //Création d'un objet paint sur lequel on va ecrire le texte
            Paint p = new Paint();
            p.setColor(Color.BLACK);
            p.setStyle(Paint.Style.FILL);

            //Le canvas affiche l'objet paint
            canvas.drawPaint(p);


            //Configuration du texte à afficher
            p.setColor(Color.WHITE);
            p.setTextSize(150);
            //Gestion de l'alignement du texte dans l'objet Paint
            p.setTextAlign(Paint.Align.CENTER);

            //Affichage des chiffres aléatoirement sur l'écran.
            //for(int s = 0;s<10; s++)
            //{
            //    canvas.drawText(String.valueOf(s),(float)(Math.random()*getWidth()+120),(float)(Math.random()*getHeight()-100),p);
            //}

            //afin de tester l'évènementiel je ne crée qu'un chiffre une fois l'évènementielle finalisé, il faudra généraliser.
            canvas.drawText("1",(getWidth()/2),(getHeight()/2),p);
            Log.i("AuthenticationView","onTouchEvent() : x: " + (getWidth()/2) + " || y: " + (getHeight()/2));

            Log.i("AuthenticationView","onDraw(): ended");
        }
    }
}
