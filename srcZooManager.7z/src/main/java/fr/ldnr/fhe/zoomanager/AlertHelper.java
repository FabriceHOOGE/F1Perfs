package fr.ldnr.fhe.zoomanager;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by fabri on 18/04/2017.
 */

public class AlertHelper extends SQLiteOpenHelper{
    public AlertHelper(Context context)
    {
        super(context, "alerts", null, 1);
    }

    //est appelé lors de la premiere création de la table. Installation de l'application.
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE alert(id INT PRIMARY KEY, title TEXT, location TEXT)");
    }

    //est utilisée lors de changement de schema dans la base de données
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    }

    public int insertAlert(String title, String location)
    {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO alert(title, location) VALUES (?,?)", new Object[]{title, location});
        Cursor c = db.rawQuery("SELECT COUNT(*) c FROM alert WHERE location=?",new String[]{location});
        if(c.moveToFirst())
        {
            int nb = c.getInt(0);
            c.close();
            return nb;
        } else
        {
            c.close();
            return 0;
        }
    }
}
