package fr.ldnr.fhe.zoomanager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;


/**
 * Created by fabri on 12/04/2017.
 */


public class AuthenticationActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new AuthenticationView(this));
    }

    private class AuthenticationView extends View {

        // Shhhhh..., keep it secret
        public static final String SECRET_CODE = "123";
        // Positions of the digits on screen
        private int positions[][];
        // Which digits were entered for now
        private String enteredCode = "";

        public AuthenticationView(Context context) {
            super(context);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                //pixel margin around each digit, for fat fingers
                final float margin = getHeight() * 0.1f;
                for (int i = 0; i < 10; i++) {
                    if (event.getX() > positions[i][0] - margin &&
                            event.getX() < positions[i][0] + margin &&
                            event.getY() > positions[i][1] - margin &&
                            event.getY() < positions[i][1] + margin)
                        // so they touched number i
                        enteredCode += String.valueOf(i);
                }
                Log.d("AuthenticationView", "Entered code for now : " + enteredCode);

                if (enteredCode.contains(SECRET_CODE)) {
                    Intent intent = new Intent(AuthenticationActivity.this,
                            MapActivity.class);
                    startActivity(intent);
                }
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            // * 1 - Creation
            positions = new int[10][2]; // 0 = x, 1 = y ; 0,0 is top left
            for (int i = 0; i < 10; i++) {
                positions[i][0] = (int) (Math.random() * getWidth());
                positions[i][1] = (int) (Math.random() * getHeight());
            }

            // * 2 - Paint
            Paint paint = new Paint();
            //pure flashy green
            paint.setARGB(255, 0, 255, 0);
            //big, 20% screen
            float textSize = getHeight() * 0.2f;
            paint.setTextSize(textSize);
            paint.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i < 10; i++) {
                canvas.drawText(String.valueOf(i),
                        positions[i][0],
                        positions[i][1] + textSize / 2, // base point for text : bottom line of text
                        paint);
            }
        }
    }
}
