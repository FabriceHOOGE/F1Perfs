package fr.ldnr.fhe.zoomanager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Toast;
import android.view.View;

/**
 * Created by fabri on 10/04/2017.
 */

public class MapActivity extends Activity{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Log interne ici un log d'information
        Log.i("MapActivity","onCreate(): ended");

        //Message visible sur l'application dont le temps de présence est prédéfini
        Toast.makeText(this, "Voici la carte", Toast.LENGTH_LONG).show();

        setContentView(new MapView(this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("MapMenagerie","onCreate(): ended" + data.getLongExtra("time", 0));
        //on récupère le nombre de milliseconds, on divise par 1000 pour avoir des secondes
        long s = data.getLongExtra("time", 0)/1000;

        //getQuantityString prend un entier en 2eme parametre, ici on gère si le pluriel ou le singulier doit etre utilisé
        String seconds = getResources().getQuantityString(R.plurals.seconds, (int)s);

        //on fabrique la chaine de caractère à afficher
        String text = getString(R.string.map_time,s, seconds);

        Toast.makeText(this,
                //"Vous êtes restés " + data.getLongExtra("time", 0) + "ms en ménagerie"
                text, Toast.LENGTH_LONG).show();
    }
//===================================================================================================================================
//===================================================================================================================================
//===================================================================================================================================
    //Classe privée imbriquée pour gérer l'affichage/la vue de cette activité
    private class MapView extends View{

        //Constructeur utilisant le constructeur herité
        public MapView(Context context)
        {
            super(context);
        }


        @Override
        public boolean onTouchEvent(MotionEvent event) {
            //Selon le type d'évènement de type toucher on effectue le changement d'activité
            if(event.getActionMasked() == MotionEvent.ACTION_DOWN)
            {
                //Création d'un objet d'intention qui effectuera le changement d'activité
                Intent intent = new Intent(MapActivity.this, MenagerieActivity.class);

                //A gauche ou a droite
                //Un  booleen recoit le résultat de la comparaison entre l'endroit touché a l'écran(coordonnées X) et la largeur de l'écran /2
                boolean right = event.getX() > this.getWidth()/2;
                //L'objet intent rempli un objet Map avec la clef right et la valeur du booleen
                intent.putExtra("right",right);

                //startActivity est une méthode de notre activité héritée
                startActivityForResult(intent, 0);
            }
            return true;
        }

        //Définition de la méthode onDraw
        protected void onDraw(Canvas canvas)
        {
            super.onDraw(canvas);
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.zoo_map);
            canvas.drawBitmap(bitmap,0,0,null);
        }
    }
}
