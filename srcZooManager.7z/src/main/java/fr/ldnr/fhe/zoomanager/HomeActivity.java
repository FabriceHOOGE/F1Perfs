package fr.ldnr.fhe.zoomanager;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/**
 * Created by fabri on 13/04/2017.
 */

public class HomeActivity extends Activity implements View.OnClickListener{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        InputStream is;
        try
        {
            is = getAssets().open("news.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("utf-8")));
            String news = "";
            String line;
            while((line = br.readLine()) != null)
            {
                news += line +"\n";
            }
            Log.i("HomeActivity", "News: "+ news);
            is.close();
            TextView tvNews = (TextView)findViewById(R.id.home_news);
            tvNews.setText(news);
        }catch(Exception ex) {}

        //Solution 1 : l'activité ecoute le bouton
        Button bt = (Button)findViewById(R.id.home_gotomap);
        bt.setOnClickListener(this);

        //Solution 3 : une classe anonyme écoute le bouton
        Button btEmail = (Button)findViewById(R.id.home_send);
        btEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    startActivity(intent);
                }catch(Exception e)
                {
                    Intent intent = new Intent(Intent.ACTION_SEARCH);
                    intent.putExtra(SearchManager.QUERY, "Android email apk");
                    startActivity(intent);
                }
            }
        });
    }

    //solution 5 : définition d'une action dans le XML
    //implémentation de la méthode correspondante dans le code Java
    public void gotoAlert(View v)
    {
        Intent intent = new Intent(this, AlertActivity.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        //en fonction de la source.
        switch(v.getId())
        {
            case R.id.home_gotomap:
                Intent i = new Intent(this, MapActivity.class);
                startActivity(i);
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //similaire au getResources() ou getAsset()
        getMenuInflater().inflate(R.menu.home, menu);

        //Récupération des préférences
        SharedPreferences prefs = getSharedPreferences("main", MODE_PRIVATE);
        MenuItem saveInDB = menu.findItem(R.id.menu_save_in_db);
        saveInDB.setChecked(prefs.getBoolean("saveInDB",false));
        return true;
    }

    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        switch(item.getItemId())
        {
            //Changement d'activité
            case R.id.menu_alert:
                Intent intent = new Intent(this,AlertActivity.class);
                startActivity(intent);
                return true;
            //Coche et décoche ce sous menu chaque fois qu'on click dessus
            case R.id.menu_save_in_db:
                item.setChecked(!item.isChecked());
                //Sauvegarde de préférence
                SharedPreferences prefs = getSharedPreferences("main", MODE_PRIVATE);
                SharedPreferences.Editor e = prefs.edit();
                e.putBoolean("saveInDB",item.isChecked());
                e.commit();
                return true;
            default:
                return false;
        }
    }
}
