package fr.ldnr.fhe.zoomanager;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.annotation.StringDef;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by fabri on 14/04/2017.
 */

public class AlertActivity extends Activity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alert);

        //récupération du composant
        AutoCompleteTextView tvLocation = (AutoCompleteTextView)findViewById(R.id.alert_locations);
        //récupération des données
        String[] locations = getResources().getStringArray(R.array.location);
        //Création de l'adaptateur qui relie un layout (représentation) aux données (location)
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,locations);

        //Ajout de l'adaptateur au TextView
        tvLocation.setAdapter(aa);
    }

    public void sendAlert(View v)
    {
        CheckBox emergency = (CheckBox)findViewById(R.id.alert_emergency_chbx);
        EditText etAlertLocation = (EditText)findViewById(R.id.alert_locations);
        Editable textAlertLocation = etAlertLocation.getText();
        EditText etAlertInfo = (EditText)findViewById(R.id.alert_informations);
        Editable textAlertInfo = etAlertInfo.getText();
        EditText etAlertTitle = (EditText)findViewById(R.id.alert_title);
        Editable textAlertTitle = etAlertTitle.getText();

        if(emergency.isChecked())
        {
            String alertText = getString(R.string.alert_message_emergency,textAlertInfo);
            Toast.makeText(this,alertText, Toast.LENGTH_LONG).show();
        }else
        {
            String alertText = getString(R.string.alert_message,textAlertInfo);
            Toast.makeText(this,alertText, Toast.LENGTH_LONG).show();
        }
        SharedPreferences prefs = getSharedPreferences("main", MODE_PRIVATE);
        if(prefs.getBoolean("saveInDB",false))
        {
            Log.i("AlertActivity", "Saving...");
            if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
            {
                String line = textAlertTitle + "," + textAlertLocation + "," + textAlertInfo + "\n";
                try
                {
                    //récupération du chemin pour le stockage solution 3
                    File dir = this.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                    //création de l'arborescence si elle n'existe pas.
                    dir.mkdirs();
                    File f = new File(dir, "alerts.csv");
                    FileWriter fw = new FileWriter(f, true);
                    fw.write(line);
                    fw.close();
                }catch(IOException ex)
                {
                    Log.e("AlertActivity","SDCard error", ex);
                }
            }else
            {
                Log.w("AlertActivity", "No SDCard");
            }
        }

        AlertHelper h = new AlertHelper(this);
        int nb = h.insertAlert(textAlertTitle.toString(), textAlertLocation.toString());
        Toast.makeText(this, getString(R.string.alert_same_location, nb), Toast.LENGTH_LONG).show();
    }
}
